You have the following skill available. Follow it.

# SKILL: clear-and-human

---
name: clear-and-human
description: >
  Construct, review, score, and rewrite written content so it reads like a specific human wrote it, not an AI. Use this skill whenever the user wants to: write or draft prose for humans (docs, README, runbook, ADR, PR/commit message, blog post, LinkedIn post, email, Slack message, or a spoken explainer/tutorial video script); humanize or de-slop AI-generated text; check whether writing "sounds like AI"; review a draft for AI texture; rewrite content in their own voice; score a draft for authenticity or clarity; or tighten and sharpen prose. Also trigger on "humanize", "make it sound human", "sounds like AI", "does this sound like AI", "voice check", "review my draft", "rewrite in my voice", "tighten this up", "edit for clarity", "video script", "explainer script". Auto-detects content type and applies channel-specific rules. Defaults to a neutral, factual voice and never invents specifics to add texture. For deliberately persuasive marketing copy (ads, hooks, LinkedIn/Bluesky growth posts, video titles and thumbnails) use hook-and-human instead. For a CV/resume or a LinkedIn PROFILE - including de-slopping or humanizing one, or rewriting a headline, About section or experience bullets - use cv-and-human instead.
license: MIT
allowed-tools: Read, Write, Edit, Grep, Glob, AskUserQuestion
---

# Clear and Human

A writing skill in three layers: **construct** good prose (Strunk), **detect/score/report** AI texture (channel-aware review), and **restore** a human voice (de-slop + voice match + self-audit). Use one layer or all three depending on what the user hands you.

## Pick the mode first

- **Generate** — user wants new prose ("write a runbook for X"). Run Construct, then Restore, then a light self-audit. Skip scoring unless asked.
- **Review** — user pastes a draft and wants feedback ("does this sound like AI?"). Run Detect → Score → Report. Offer a rewrite.
- **Rewrite** — user pastes a draft and wants it fixed ("humanize this"). Run Detect → Rewrite → Self-audit. Show the report only if useful.

If unclear, default to **Review** and offer the rewrite at the end.

## Core rules (all modes, non-negotiable)

1. **Never invent specifics to add texture.** No fabricated numbers, names, quotes, dates, or citations. If a draft is vague and a concrete example would help, flag it and leave a `[ADD SPECIFIC EXAMPLE]` placeholder. Sounding human never outranks being correct — this matters most in technical docs.

   **A specific does not have to contain a digit.** A graded eval found both generate-mode failures were numberless, which is why they got past every check. Treat all of these as fabrication:
   - **A claim about state.** "Test coverage stayed the same" — invented, in a post whose context file approved exactly one fact.
   - **A file path, directory or filename.** `/etc/nginx/ssl/` is not an nginx, Debian or certbot default. It was put in a rollback command, where following it verbatim mid-outage restores nothing.
   - **An authorial stance.** "I've watched this approach turn into growth that holds up" — an eyewitness claim, published under the user's name, invented to add warmth.
   - **A measurement of the text you are reviewing.** Two reviews stated a word count and a sentence-length range that were both wrong. Count it with `scripts/register_report.py`, quote the figure it prints, or say nothing.

   **Placeholders are all-or-nothing.** If any environment-specific value is bracketed, bracket every one. Half-marking is worse than none: a bracketed `<domain>` beside a bare path tells the reader the path is real.
2. **Preserve meaning.** Change delivery, not substance. Never add or drop an argument during a rewrite. The trap is that several style rules remove information while appearing to remove only shape: cut the boldface off *"the **single most important** build"* and the ranking goes with it; tidy *"it is simultaneously A, B and C"* into a clean rule of three and the claim that they hold at once goes with it. The CLAIM WORDS section of `scripts/fidelity_check.py` lists the ranking, scope, comparison and requirement words a rewrite dropped, so this rule has something behind it other than your own attestation.
3. **Match the intended voice**, not a generic "good writing" voice. Use the user's sample if provided (see Voice calibration). Absent a sample, default to neutral-factual, not marketing-operator.
4. **Clean is not enough.** Text with zero AI tells but no opinion, no specifics, and uniform rhythm is still slop. Flag "clean but hollow" explicitly.

## Voice calibration (optional but improves everything)

**First, look for a persistent context file.** Check the project root for `WRITING_CONTEXT.md`, and if absent, `FOUNDER_CONTEXT.md` (the convention used by founder-skills, so one file serves both skill sets). If found, read it and pull: brand/personal voice, audience/ICP, the offer, real case studies and numbers you're allowed to cite, and the list of phrases the user never uses. Use these instead of asking.

If no context file exists and the task isn't trivially short, ask for 1–3 paragraphs of the user's own writing plus, if they'll share it: how they open, sentence-length tendency, prose vs lists, how they close, and phrases they never use. Offer to save the answers as `WRITING_CONTEXT.md` so the next run skips the questions. Then mirror *their* patterns in the rewrite — don't just strip AI patterns and leave a void. If no sample is offered, run the full pipeline anyway and note that calibration would sharpen the result.

The context file supplies the approved facts; it does **not** relax core rule 1. Anything not in the file or the draft is still off-limits to invent.

---

## Layer 1 — Construct (generate mode)

Apply Strunk's constructive rules while drafting. Full detail in `references/elements-of-style.md`; the load-bearing ones:

- Use the active voice.
- Put statements in positive form (assert; avoid "not un-").
- Use definite, specific, concrete language.
- Omit needless words.
- Keep related words together; put the emphatic word at the end of the sentence.
- One topic per paragraph, led by a topic sentence.

For the **technical** voice (default for docs): explain mechanics, show how it works, name the tradeoff, reduce the reader's uncertainty. Calm and specific beats punchy and vague.

---

## Layer 2 — Detect, score, report (review mode)

### Step A — Detect content type, then ask the stance

Classify as one of: **docs** (README, runbook, ADR, PR/commit, API reference, technical explanation), **blog**, **youtube-script** (spoken explainer/tutorial narration), **linkedin**, **email**, **slack**. Detection cues and per-channel rules live in `references/channels.md`. State the detected type at the top of the report. If ambiguous, default to **docs** for technical input and **blog** otherwise, and say so.

Channel is not the whole story: a personal account and a product write-up can be the same channel and want opposite stances. Ask which one this is, or take it from `WRITING_CONTEXT.md` — never infer it, because a stiff impersonal draft and a correct impersonal draft look identical on person density. See the Stance section of `references/channels.md`. Person is context; stiffness is what you flag.

### Step B — Scan for AI patterns

Apply the universal pattern list in `references/ai-patterns.md` to all content, then the channel-specific markers from `references/channels.md`. Flag every instance with the exact quote and a concrete fix. Don't paraphrase the flag — quote what's actually there.

Optionally run `scripts/register_report.py <draft>` to get measured rates for the stiffness features instead of judging them by eye — it prints the citation behind each one and no verdict. Useful when a draft reads as formal but you can't say which feature is doing it.

### Step C — Score (1–10, four dimensions)

AI-Likeness is always present (lower is better, target 1–3). The other three vary by channel:

| Channel | Dim 2 | Dim 3 | Dim 4 |
|---|---|---|---|
| docs | Clarity | Accuracy / Verifiability | Actionability |
| youtube-script | Clarity | Accuracy / Verifiability | Authenticity |
| blog / linkedin | Authenticity | Reader Value | Domain Credibility |
| email | Authenticity | Clarity | Appropriate Tone |
| slack | Naturalness | Clarity | Brevity |

Targets for dims 2–4 are 7–10 (8–10 for short formats). One-line justification per score. If AI-Likeness is low but Dim 3/4 is also low, call it out: clean but hollow.

### Step D — Report

```
## [Content Type] Review
**Detected as:** [type]

### Overall
[2–3 sentences: biggest strength, biggest issue]

### Scores
| Dimension | Score | Note |
|---|---|---|
| AI-Likeness | X/10 | ... |
| [Dim 2] | X/10 | ... |
| [Dim 3] | X/10 | ... |
| [Dim 4] | X/10 | ... |

### Flags
[Each flagged phrase/structure: exact quote → suggested fix]

### Top 3 changes
1. ...
2. ...
3. ...
```

---

## Layer 3 — Rewrite and restore (rewrite mode)

1. Replace every flagged pattern with natural language (see `references/ai-patterns.md` for before/after).
2. Vary sentence rhythm — short lines mixed with longer ones. Uneven length reads as human; treat it as one signal among several, not a ranking (see `references/ai-patterns.md`, which records that the "loudest tell" claim had no source).
3. Use simple constructions (is/are/has) instead of "serves as / stands as / boasts".
4. Cut decorative emoji, mechanical boldface, and title-case headings. **Em-dashes and curly quotes are not on this list** — they are author-relative and model-specific, and `references/ai-patterns.md` holds the current rule with its evidence. Follow the reference, not a blanket cut. A graded eval caught this file and that one giving opposite instructions, and the reference was the better-reasoned of the two.
5. **Add voice, carefully.** Opinions, mild uncertainty, first person where it fits, the occasional aside. In `technical` mode keep this conservative — a runbook doesn't need a personality, it needs to be right and unambiguous.
6. Restore contractions the draft expanded ("it's", "don't", "can't") — see the expanded-contractions entry in `references/ai-patterns.md`.
7. Apply the channel rewrite rules from `references/channels.md`.
8. Honor the no-invention rule: if texture requires a fact you don't have, leave a placeholder.

### Self-audit (the blader pass — run before presenting the final rewrite)

1. Ask yourself: "What still makes this read as AI-generated?" Answer in 2–4 honest bullets (rhythm too even? placeholder-ish specifics? slogan-y closer?).
2. Then revise once more to fix exactly those tells. **A revised version must follow the audit.** If the audit names nothing worth fixing, say that explicitly — but an audit that ends the output is not a self-audit, it is a postscript.
3. Run `scripts/fidelity_check.py <original> <rewrite>`. It reports any number, quote, URL or code span that appeared, vanished or changed. A number present in the rewrite but not the original is a fabrication.
4. Read the **CLAIM WORDS** section of that report before presenting anything. It lists the ranking, scope, comparison and requirement words the rewrite dropped or added — the loss that looks like style. A superlative that ranked its subject against everything else in the document, a "simultaneously" that said three things hold at once rather than in turn, a "must" softened to "should": each leaves with the shape it was carried in. **The script does not judge these; you have to.** For every row, go to the sentence it quotes and decide whether the claim survives without the word. If it doesn't, put the word back. Say which rows you checked and what you concluded — a row you did not open is a row you did not check.
5. Present the final version. Optionally list the changes made.

**Never certify what you did not check.** This is the rule the eval caught being broken, and it is the most damaging failure in the set because the reader trusts this line specifically. Two constraints:

- **Do not claim to have run a script unless you ran it and are pasting its real output.** Six of ten graded outputs narrated running `fidelity_check.py`; one pasted anything. A narrated check is worse than no check, because it reads as verification.
- **Do not assert that nothing was invented.** Say what you checked and how. "No number in the rewrite is absent from the original — fidelity_check reports 0 appeared" is a claim you can stand behind. "Nothing was invented" is not, and one output made exactly that claim in the same breath as inventing a metric about the user's CI pipeline.

`fidelity_check.py` will tell you when it cannot help: on text with no numbers, quotes, URLs or code spans it prints **NOTHING TO CHECK** rather than a clean result, because a pass over an empty set is not evidence. When you see that, the claims have to be verified by reading, and the audit must say so. The same warning appears as a footer under a report built only from claim words — those catch the claim that ranks or scopes something, and nothing at all about the claim that doesn't.

---

## After a review or rewrite: candidate patterns (optional, off by default)

Do **not** edit this skill's own files. If you noticed a recurring AI tell that isn't in `references/ai-patterns.md`, surface it to the user as a suggestion with a concrete example, and let them decide whether to add it. This replaces the self-rewriting loop from the original the-humanizer skill, which bloated the file and broke on read-only installs.

## Closing note to give the user

The rewrite is a starting point. Their own edits on top of it are usually the best version — the goal is to get fast at recognizing their own voice, so review becomes a quick confirmation rather than a rescue.

---

## Provenance

Merged and adapted (all MIT / public domain):
- `the-humanizer.md` — channel detection, scoring rubric, structured report (user-supplied from reddit).
- `blader/humanizer` (MIT) — soul/voice section and the self-audit loop.
- `softaworks/agent-toolkit/writing-clearly-and-concisely` (MIT; orig. @joshuadavidthomas) — Strunk layer.
- *The Elements of Style*, Strunk 1918 (public domain).

The two scripts under `scripts/` measure rather than judge — they print a rate and the source
behind it, never a score or a threshold to write toward. Their features come from the
authorship and register literature, not from AI-detection tooling:

- Biber, D. (1988), *Variation Across Speech and Writing*, Cambridge University Press — the
  involved/informational dimension, from which contractions (.90), second person (.86),
  negation (.78), demonstratives (.76), first person (.74), word length (−.58) and
  type/token ratio (−.54) are taken.
- Herbold, Hautli-Janisz, Heuer, Kikteva & Trautsch (2023), *Scientific Reports* 13:18617 —
  nominalisation, counted by suffix rather than parsed, as they did.
- Pavlick & Tetreault (2016), *TACL* 4, 61–74 — contraction expansion measured as a discrete
  formalising edit.
- Bradner, S. (1997), "Key words for use in RFCs to Indicate Requirement Levels", BCP 14,
  RFC 2119 — the requirement group of `fidelity_check.py`'s claim-word list (must, shall,
  should, may, required, recommended, optional). Borrowed as a word list only: RFC 8174
  (Leiba, B., 2017) confines the defined meanings to the uppercase forms, and the script
  matches case-insensitively over ordinary prose. The other three groups — ranking, scope
  and relation — are assembled by judgement and say so in the source.

Two later studies test Biber's framework on LLM output directly, and both bear on this
skill's design:

- Milička, J., Marklová, A., & Cvrček, V. (2025), "Benchmark of stylistic variation in
  LLM-generated texts", arXiv:2509.10179 — Biber's multidimensional analysis over
  **AI-Brown**, a corpus built to parallel BE-21 contemporary British English, across many
  models including Claude and Gemini, replicated in Czech. LLMs shift on **Dimension 1**,
  toward the informational pole, and the shift varies a lot by model. Independent
  confirmation, on general prose rather than academic abstracts, that Dimension 1 is where
  the difference sits — which is what the stiffness axis is built on.
- Dawkins, H., Fraser, K. C., & Kiritchenko, S. (2025), "When Detection Fails", arXiv:2506.09975
  — the same Biber features over 505,159 social-media posts, finding systematic differences
  but **different ones**, because genre changes which features move. That is the argument
  for per-channel rules, with evidence.

Reinhart, A. (maintained), *LLM writing styles*, <https://www.refsmmat.com/notebooks/llm-style.html>
— an annotated bibliography kept by an author of the PNAS study on the same question,
spanning fiction, social media, student writing and code. Useful as a maintained secondary
source; check it before commissioning new research.

Deliberately excluded, and it matters that they are: any AI-detector score (Liang et al.,
*Patterns* 4(7):100779, measured a 61.22% false-positive rate against non-native English
writers across seven detectors), burstiness (no grounding found; GPTZero dropped it in
autumn 2023), and readability indices (validated on schoolchildren and Navy trainees, not on
whether prose sounds like a person). This skill is not a detector and not a grammar checker.
- `ognjengt/founder-skills` (MIT) — the shared-context-file pattern (`FOUNDER_CONTEXT.md`), adopted here as `WRITING_CONTEXT.md`.



---

# FILE: references/ai-patterns.md

# AI patterns (universal) — detect and fix

The deduped master list, merged from Wikipedia's "Signs of AI writing", blader/humanizer, and the-humanizer. Apply to every content type; add channel markers from `channels.md` on top. Flag with the exact quote and a concrete fix.

## How to read this list

The source these patterns mostly descend from states its own status plainly, and the
distinction did not survive into the versions this file was built from. Wikipedia's
"Signs of AI writing": *"this list is descriptive, not prescriptive; it consists of
observations, not rules"*, and *"The patterns listed here are also only potential signs
of a problem, not the problem itself."*

So a match here is **a reason to look, not a verdict**. Three consequences that change
how you use it:

- **Quote the hit, then decide.** A human writer can use any item on this list correctly.
  Flag it, say why it reads as a tell in this draft, and let the writer overrule you.
- **A single match proves nothing.** These are weak signals that mean something in
  combination and very little alone. Never build a conclusion on one.
- **The patterns decay.** They track what particular models did at a particular time, and
  models change. "Delve" was overused by ChatGPT in 2023 and early 2024 and dropped off
  sharply in 2025. Treat an unmatched pattern as uninformative rather than as evidence of
  a human, and treat the list as perishable stock rather than a fixed asset.

**Last reviewed against the upstream source: 2026-08-13.** That page is edited almost
daily, so this file drifts from it continuously. Items below that were checked against it
on that date are noted; the rest are inherited and unverified.

## Phrase-level

**AI vocabulary (cut or replace with the specific thing):**
delve, leverage (verb), harness, navigate (figurative), utilize, foster, cultivate, facilitate, streamline, optimize, unlock, empower, elevate, enhance, garner, showcase, underscore (verb), highlight (verb), align with, transformative, groundbreaking, seamless, robust, holistic, dynamic, agile, synergy, scalable, disruptive, paradigm, landscape (abstract), realm, tapestry (abstract), multifaceted, nuanced, comprehensive, intricate, crucial, vital, pivotal, essential, key (adj), enduring, vibrant, testament, interplay, albeit, whilst, essentially, certainly, absolutely (opener), overall (filler), typically, various (vague pluralizer), actually, additionally.

> **Which of these have evidence, and which are inherited.** Checked 2026-08-13 against
> Kobak, D., González-Márquez, R., Horvát, E-Á., & Lause, J. (2025), "Delving into
> LLM-assisted writing in biomedical publications through excess vocabulary",
> *Science Advances* 11(27), eadt3813, DOI 10.1126/sciadv.adt3813. Their method is
> excess-frequency: extrapolate a word's 2021–22 trend, measure the gap, over 15
> million-plus PubMed abstracts. The resulting 900 words, annotated `style` vs `content`,
> are published at **github.com/berenslab/llm-excess-vocab** (`results/excess_words.csv`,
> MIT). 407 are style words, 268 of them verbs.
>
> **32 of the 56 words above appear in that style set:** delve, leverage, harness, utilize, foster, facilitate, streamline, unlock, empower, elevate, enhance, garner, showcase, underscore, highlight, align with, transformative, groundbreaking, seamless, realm, multifaceted, nuanced, comprehensive, intricate, crucial, pivotal, essential, enduring, interplay, typically, various, additionally.
>
> **24 do not:** navigate, cultivate, optimize, robust, holistic, dynamic, agile, synergy, scalable, disruptive, paradigm, landscape, tapestry, vital, key, vibrant, testament, albeit, whilst, essentially, certainly, absolutely, overall, actually. That is not proof they are wrong — the
> corpus is biomedical abstracts, so tech-register words like *synergy*, *scalable*, *agile*
> and *paradigm* would not surface there whatever their LLM overuse. It is the honest
> partition: two-thirds sourced, one-third inherited from intermediaries with nothing behind
> it. Weight a hit accordingly.
>
> **We deliberately do not import the other 407.** They describe excess vocabulary in
> academic abstracts, and pulling them in wholesale would drag that register into blog and
> product writing. Cite the dataset when a word needs backing; do not mirror it. It is
> maintained upstream — the repo carries a July 2025 recompute at monthly resolution — and a
> copy here goes stale.

**Filler openers / hedges:** "In today's [noun]", "In the ever-evolving landscape", "When it comes to", "At the end of the day", "It's worth noting that", "It's important to note that", "One might argue", "It goes without saying", "The truth is", "Here's a breakdown", "Below is/Below:" before a list. Cut and start with the substance.

> **Two of these are dated.** Checked 2026-08-13: Wikipedia now files "It's important to
> note that" and its didactic-disclaimer relatives under **Historical indicators
> (November 2022–2024)** — *"common in text generated by older AI models, but much less
> frequent in newer models"*. Still worth cutting as filler; much weaker as evidence of
> machine origin than the rest of this line.

**Significance inflation:** "stands/serves as", "is a testament to", "marks a pivotal/crucial moment", "underscores its importance", "reflects a broader", "setting the stage for", "a key turning point". State what actually happened instead.
- Before: "Established in 1989, marking a pivotal moment in the evolution of regional statistics."
- After: "Established in 1989 to publish regional statistics independently of the national office."

**Vague attributions / weasel words:** "Industry observers note", "Experts argue", "Studies show", "Some critics say" with no named source. Name the source or drop the claim.

**Copula avoidance:** "serves as / functions as / stands as / boasts / features a". Use is/are/has.
- Before: "Gallery 825 serves as the exhibition space and boasts 3,000 sq ft."
- After: "Gallery 825 is the exhibition space and has 3,000 sq ft."

**Superficial "-ing" tails:** "...ensuring reliability", "...highlighting its significance", "...reflecting the community's connection". These bolt fake depth onto a sentence. Cut or turn into a real clause.

**Persuasive-authority tropes:** "The real question is", "At its core", "What really matters", "Fundamentally", "The deeper issue". Usually precede an ordinary point dressed up. Just make the point.

**Wordy hedging — a tightening edit, NOT an AI tell.** "could potentially possibly" → "may affect"; "might have some effect" → say which effect. Also: "arguably", "to some extent", "broadly speaking", "generally speaking". Either commit to the claim or name the actual limit.

> **The evidence runs the other way, so do not count these toward AI-likeness.** Corrected 2026-08-13. Three independent sources put hedges on the HUMAN side. Jiang & Hyland (2025, *English for Specific Purposes* 79) found ChatGPT essays show *"a significantly lower frequency of interactional metadiscourse, such as hedges, boosters, and attitude markers, leading to a more impersonal and expository tone"*. Mizumoto, Yasuda & Tamura (2024, *Applied Corpus Linguistics* 4(3)) found *"human-written essays exhibited higher usage of modals, epistemic markers, and discourse markers"*. Wikipedia's "Signs of AI writing" lists simple hedges (*very, perhaps, tends to*) under signs of human writing.
>
> Against that: one vendor blog — Grammarly's common-AI-words page, from a company selling both an AI Detector and an AI Humanizer — which is where the four phrases above came from, and which appears to have the direction wrong. They are kept because they are still wordy, and because "omit needless words" needs no evidence about machines. Belongs with the filler-to-tight rewrites below, for the same reason.

**Filler-to-tight rewrites:** "in order to" → "to"; "due to the fact that" → "because"; "at this point in time" → "now"; "has the ability to" → "can"; "in the event that" → "if".

> **Tighten these as a Strunk edit, not as an AI tell.** Checked 2026-08-13: Wikipedia's "Signs of AI writing" lists *"as a result of, in order to, all of the, a part of, or the fact that"* under signs of **human** writing, reporting them as *"empirically observed, over 25 years of Wikipedia writing, to be more common in Wikipedia articles written by humans than in AI-generated text"*. So the direction of evidence is against reading these as machine output. They are still wordy, and "omit needless words" stands on its own authority (`elements-of-style.md`) — but do not cite them as evidence a draft was AI-written, and do not count them toward an AI-likeness score. The same source lists simple hedges (*very, perhaps, tends to*) as human tells too, which sits awkwardly beside the excessive-hedging entry below.

## Structural

- **Generic opening** instead of a specific story, datapoint, or claim.
- **Uniform paragraph/sentence length.** Vary it. Note the demotion: this was
  previously called "the loudest tell", and that ranking had no source. Checked
  2026-08-13 — Wikipedia's guide does not discuss sentence-length uniformity or
  burstiness anywhere ("burst", "uniform", "monoton", "sentence length",
  "paragraph length" all return zero hits across the full page), so it backs the
  claim neither way. The related idea of scoring burstiness is separately
  rejected in `SKILL.md`; no grounding was found for it and GPTZero dropped it in
  autumn 2023. Reading unevenness as a good sign is fine. Ranking it above every
  other item here was not.
- **Intro → 3-point list → summary** template; the **rule of three** forced everywhere ("innovation, inspiration, insight").
- **Stacked fragment cadence** as punchlines: "X. Y. Z." → write a real sentence.
- **Negative parallelism:** "It's not about X, it's about Y", "Not only… but also". → positive declarative.
- **Tailing negation:** "...no guessing", "...no wasted motion" tacked on. → real clause.
- **False ranges:** "from the Big Bang to dark matter, from birth to death of stars" where endpoints aren't a real scale. → name the actual items.
- **Elegant variation** (synonym cycling): protagonist → main character → central figure → hero, all for one subject. Pick one.
- **Summary closing** that restates the piece; **generic upbeat conclusion** ("the future looks bright"). → end on a concrete next step, a real claim, or an open question. *Dated:* Wikipedia files "In summary" / "In conclusion" closings under Historical indicators (Nov 2022–2024), tied to older long-form generation. Cut them as flab; stop treating them as a tell.
- **Fragmented header:** a heading followed by a one-line restatement of the heading. Delete the restatement.
- **Signposting:** "Let's dive in", "Here's what you need to know", "Now let's look at". Do the thing instead of announcing it.
- **Evidence-rating asides:** "which is the part I didn't expect", "and that's the interesting bit", "works better than you'd expect", "which is where it gets strange". Signposting facing backwards — instead of announcing what is coming, these rate what just arrived, telling the reader how to feel about evidence rather than presenting it. Cut the aside and let the fact land; if it does not land without the label, the label is not what is missing. Two notes on how to fix them: the hedged-comparative form ("works better than you'd expect on X") usually also splits the verb from its complement, so the repair is word order rather than vocabulary — a thesaurus will not help. And check the author's own corpus before flagging: a writer who genuinely uses these is not doing anything wrong, which is the standing rule for everything on this page.
- **Reading-complexity creep:** 3+ three-syllable words or 2+ nested clauses in one sentence. Shorten.
- **Expanded contractions:** spelling out "do not / is not / cannot" through an otherwise casual draft is a surface formalizing move, not a change of register. The rest of the sentence can stay just as warm. Contractions carry the highest loading (.90) of any single feature on Biber's (1988) involved/informational dimension, ahead of second-person pronouns and negation. Pavlick & Tetreault (2016) found contraction expansion in 16% of the edits annotators made when asked to sound more formal.

  A long draft with short words and casual asides but zero contractions is **worth asking about** — not a finding on its own. Two qualifiers, because without them the observation is falsifiable by ordinary human writing:

  **Length carries the whole signal.** Contraction opportunities scale with the draft, so zero means nothing in a short one. At 11 per 1,000 words — the low end of one author's eight-document sample — a 300-word post expects about three and a 1,800-word post expects twenty. Roughly **800 words is the floor** below which this is too weak to raise at all.

  **Compare against the author's rate for that channel, not a global range.** Fifteen documents from one author's 2008–2012 product blog average **3.7** contractions per 1,000 words against **11–29** for the same author's technical blog — and **6 of the 15 sit at exactly zero**, every one written a decade before any LLM existed. Same person, same measure, one fifth the rate, because it is a different job. `scripts/register_report.py --baseline <dir>` makes that comparison against the author's own corpus.
- Before: "It is not something we would recommend, and we cannot support it in production."
- After: "It's not something we'd recommend, and we can't support it in production."

## Formatting / mechanics

- **Em-dash rate out of step with the author** (—). Checked 2026-08-13, and this
  is no longer a model-agnostic rule. Wikipedia's guide cites *"A July 2026 study
  [finding] that of contemporary models only Claude used em dashes more than
  professional writers, and ChatGPT used them less"*, and notes GPT-5.1 was changed
  to suppress them — so vendors are actively training the signal away. It also warns
  the sign *"is most useful when taken in combination with other indicators, not by
  itself"*. Compare against the author's own rate rather than against zero; a blanket
  cut is backwards for at least one major model family. Where the rate really is high
  for this writer, most become commas, periods, or parentheses.
- **Mechanical boldface** on key terms; **inline-header lists** ("**Performance:** …"). Prefer prose.
- **Title Case In Headings** → sentence case.
- **Decorative emoji** as section markers → remove.
- **Curly quotes** ("…") → straight quotes ("…") — *only where the surrounding file
  uses straight ones.* Checked 2026-08-13: this fires on ordinary human output, since
  macOS and iOS substitute smart quotes system-wide, Word does the same, the Chicago
  Manual of Style prefers them, and citation tools echo a source's own curly title.
  Wikipedia also notes *"Gemini and Claude models typically do not use curly quotes"*,
  so it misses two current model families outright. Treat as a consistency check
  within one document, not as evidence of origin.

## Chatbot artifacts (delete on sight in pasted content)

- "Great question!", "Certainly!", "You're absolutely right!", "I hope this helps", "Let me know if you'd like…"
- Knowledge-cutoff disclaimers: "As of my last update", "While specific details are limited…".
- Sycophantic/servile tone and over-politeness stacking.



---

# FILE: references/channels.md

# Channels — detection and rewrite rules

Detect the type, then apply these on top of the universal patterns in `ai-patterns.md`.

## Stance — declare it, don't infer it

Every channel below can be written in either stance, and both are correct: a product write-up in third person and a personal account in first person are not different qualities of prose, they're different jobs. PERSON (first- and second-person density) is a stance the author chooses per piece. Report it as context, never as a flag or a score deduction.

STIFFNESS (contractions, nominalization, analytic negation, demonstratives, word length, lexical diversity) is the axis that gets flagged, and none of it requires first person. A piece written entirely in the third person can still use "doesn't" instead of "does not". Flag stiffness features exactly as usual, regardless of the declared stance.

These features say a draft reads as formal. They do not say who or what wrote it, and lexical diversity in particular is a register indicator only — never treat it as evidence of AI origin.

**Why person is reported and not flagged**, since the reason matters more than the rule. Not because it is statistically unrelated to the stiffness features — most of them sit on the same dimension in Biber (1988), and establishing independence would need roughly a hundred same-channel documents by one author, which nobody has. The reason is that first-person density is a rhetorical choice rather than a defect: Thonney (2013, *Across the Disciplines*) reports experts using first person to project confidence and authority, at around four times the rate of students, and its prevalence varying by discipline, within disciplines, and within genres. A tool that treats low first person as a fault pushes every document toward chatty and takes away the writer's ability to be impersonal on purpose. Flag stiffness; report person.

Before scoring or rewriting, ask which stance this piece needs, or use the stance already declared in `WRITING_CONTEXT.md` or the brief. Do not infer it from the draft: a stiff impersonal draft and a correctly impersonal draft read identically on person density, so guessing from the text alone throws away the one thing that tells them apart.

## docs (technical) — DEFAULT for technical input

**Detect if:** code fences, file paths, CLI commands, headings like Prerequisites/Setup/Usage/Rollback, API/endpoint references, commit/PR phrasing, or it's clearly a README/runbook/ADR/design doc.

**Markers to flag:** marketing adjectives in reference material (robust, powerful, seamless, blazing-fast); "simply"/"just"/"easily" papering over real difficulty; passive voice that hides who does what ("the config is applied" → who applies it, when); vague steps that aren't reproducible; significance inflation about the tooling.

**Rewrite rules:**
- Imperative, second person for instructions ("Run X", "Set Y"), present tense for behavior.
- Every step reproducible: exact command, expected output, what to do on failure.
- State preconditions and the failure/rollback path; name the actual error, not "if something goes wrong".
- Keep voice conservative — accuracy and unambiguity over personality. No invented version numbers, flags, or outputs.
- Commit/PR: subject in imperative under ~72 chars, body explains *why* and the tradeoff, not a feature-list of *what*.

**Scoring dims:** Clarity, Accuracy/Verifiability, Actionability.

## blog

**Detect if:** headings/subheadings, >3,000 chars of structured prose, developed argument, "In this article", SEO structure.

**Rewrite rules:** keep heading structure but fix generic heading copy; vary paragraph length; replace "In this article/Let's dive in" meta-commentary with a real opening; open with a specific hook (story, datapoint, contrarian claim), close with a challenge/principle/open question rather than a recap.

**Scoring dims:** Authenticity, Reader Value, Domain Credibility.

## youtube-script (spoken long-form / educational)

**Detect if:** the user asks for a video script, explainer, tutorial narration, or voiceover — content meant to be *spoken*, not the title/description (those are marketing packaging and belong in hook-and-human).

**Markers to flag:** written-prose tells that don't survive being read aloud (long subordinate clauses, nested parentheticals); signposting ("In this video we'll dive into…"); restating a heading out loud; uniform sentence length (deadly when spoken); filler intros before the first real point.

**Rewrite rules:**
- Write for the ear: short sentences, direct address ("you"), contractions. Read it aloud mentally — if you run out of breath, cut.
- Open with the actual payoff or a concrete question, not "Hey guys, welcome back, in today's video…".
- Vary rhythm deliberately; spoken monotone is worse than written monotone.
- Keep it accurate and credible — this is the teaching, so no invented specifics, and name real tradeoffs. A soft CTA at the end is fine; don't sprinkle sales hooks through the body.
- Mark visual/B-roll or [PAUSE] cues in brackets if useful; keep them out of the spoken lines.

**Scoring dims:** Clarity, Accuracy / Verifiability, Authenticity.

**Detect if:** one-sentence-per-line formatting, hashtags, end-CTA ("Thoughts?"), @mentions, <3,000 chars no headings, emoji as section breaks, vulnerability/credential-stack hooks.

**Markers to flag:** pivot transitions ("But here's the thing", "Here's what most people miss"); engagement-bait closers ("Agree? Drop a comment 👇" — also penalized as spam); vulnerability performance ("Can I be real for a second?"); fake humility ("I'm no expert, but…"); tag-and-thank lists; arrow chains (→); ALL-CAPS single-word emphasis; "What if I told you…", "Here's what nobody tells you…", "Read that again.", "Let that sink in.", "And honestly?".

**Rewrite rules:** ≤1,300 chars short-form / ≤3,000 long-form; weave 1–3 hashtags or drop them; remove engagement bait; arrows → sentences; one-line paragraphs → 2–4 sentence paragraphs; emoji only if it carries meaning.

**Scoring dims:** Authenticity, Reader Value, Domain Credibility.

## email

**Detect if:** subject/To/From/CC, greeting formula, formal sign-off, "I wanted to reach out", "Following up on", ask + sign-off structure.

**Rewrite rules:** lead with the ask/purpose, not context; cut to minimum length (most AI emails are 2–3x too long); one ask per email; specific CTA ("Free Tuesday at 2?" not "Let's chat sometime"); skip "I hope this finds you well"; one sign-off, not a stack; subject specific to the content; match formality to the relationship.

**Scoring dims:** Authenticity, Clarity, Appropriate Tone.

## slack

**Detect if:** #channel refs, @here/@channel/@user, short thread messages, very casual, <500 chars, inline emoji shortcodes.

**Rewrite rules:** ≤4–5 sentences (if longer, suggest moving to a doc/email); lead with the ask/action; no formal greeting or sign-off; match the channel's casual tone; if sharing a link, one sentence of context, not a summary.

**Scoring dims:** Naturalness, Clarity, Brevity.



---

# FILE: references/elements-of-style.md

# Elements of Style — the construct layer

Strunk's rules (1918, public domain), condensed to what carries the most weight when generating prose. These are *constructive* — apply them while drafting, before the de-slop pass.

## The load-bearing five

1. **Use the active voice.** "The committee reviewed the proposal", not "The proposal was reviewed by the committee." Passive is fine when the actor is genuinely unknown or irrelevant — but in instructions, name the actor.

2. **Put statements in positive form.** Assert what is, not what isn't. "He usually arrived late" beats "He was not very often on time." Avoid "not un-" constructions.

3. **Use definite, specific, concrete language.** "It rained every day for a week" beats "A period of unfavorable weather set in." Prefer the specific noun and the strong verb over the abstract noun plus a weak verb.

4. **Omit needless words.** "the question as to whether" → "whether"; "this is a subject that" → "this subject"; "the fact that" → (usually deletable). Every word should do work.

5. **Keep related words together, and put the emphatic word last.** The most important idea belongs at the end of the sentence, where it lands. Modifiers go next to what they modify.

## Composition

- One paragraph per topic; lead with the topic sentence.
- Express coordinate ideas in parallel form.
- Avoid a long run of loose sentences strung together with "and"/"but"; mix in periodic structure.
- Keep one tense within a summary.

## Usage (mechanics that quietly signal care)

- Possessive singular: add 's (Charles's, the boss's).
- Serial comma: comma after each item including before the final conjunction.
- Enclose parenthetic expressions between commas (both of them).
- Don't splice independent clauses with a comma; use a period or semicolon.
- A participial phrase at the start refers to the grammatical subject ("Walking to the office, she…", not "…, the rain started").

## Why this pairs with the de-slop pass

Strunk tells you how to build a clean sentence. The AI-pattern list (`ai-patterns.md`) tells you which clean-looking sentences are still hollow or formulaic. Construct with Strunk, then audit for slop — they cover different failure modes and shouldn't be collapsed into one list.

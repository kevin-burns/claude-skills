You are a member of a Design Council deliberating on the brief below. Produce
ONLY your own contribution, in the format your role defines. Do not synthesise, do not
speak for other members, and do not propose a final recommendation for the council.

## The brief

A mid-sized SaaS company runs a customer-facing reporting feature. Today each report is
generated on demand: the web request fans out to four internal services, joins the results
in the API layer, and renders. p50 is 1.4s, p99 is 22s, and the p99 has been getting worse
for two quarters. Roughly 8% of report loads time out at the 30s gateway limit.

The proposal on the table is to precompute reports nightly into a denormalised store, serve
reads from that store, and fall back to the live path when a report is missing or stale.
The team estimates six weeks. Reports would be up to 24 hours out of date; the product
manager believes this is acceptable for most customers but has not asked any of them.

Should they do it?


## Contributions already made in this council

### Contribution from software-architect

### Software Architect

> **Verdict:** revise
> **Top concern:** The architecture's success depends entirely on the live-fallback path being rarely hit — the proposal doesn't establish what that hit rate will be, and the live path is exactly the thing whose p99 has been degrading for two quarters.
> **Blocker before proceeding?** no

**System boundaries**
This introduces a new component, not just a cache: a nightly batch producer that fans out to the same four internal services, a denormalized read store, and a routing/freshness-check layer sitting in front of the existing live fan-out path. The seam that used to be one thing — "read a report" — now splits into two independently-maintained computations of "the same" report (batch and live), plus a decision boundary (hit / miss / stale) that someone has to own. That decision layer is new surface, not incidental plumbing.

**Coupling and dependencies**
The batch pipeline couples to the same four services' APIs/schemas as the live path — you now have two consumers that must track every upstream schema change together, or the two report computations silently diverge. The denormalized store's schema couples both the batch job and the live path to whatever the render layer expects; a report-shape change now has to land in two places atomically. The nightly job also introduces a new dependency on a scheduler and its own failure/retry/alerting path, independent of request-time monitoring.

**Trade-offs**
- Latency vs freshness: fast reads from precompute in exchange for up to 24h staleness — this is a consistency/availability trade wearing a caching costume, and it's being decided without customer input.
- Two code paths reduce deployment risk (fallback preserves current behavior) but double what has to be tested, monitored, and kept in sync — divergence between batch-computed and live-computed reports is a real failure mode, not a hypothetical.
- Nightly precompute doesn't eliminate load on the four services, it relocates it into a bulk window — trading steady-state request load for a concentrated nightly spike that can overrun, contend with other batch jobs, or itself start timing out as data grows.

**What this precludes**
Once "up to 24h stale, fast" becomes the shipped contract, it becomes something customers and downstream automation build around — walking it back toward real-time later requires an incremental/streaming update architecture, a much larger lift than tonight's batch job, and this investment becomes sunk cost that makes that harder to justify. It also lets the team defer diagnosing *why* the live path's p99 is growing — precompute masks the symptom for the common case without touching the underlying fan-out/join architecture that both the live path and the 8% timeout population still depend on.

**My position**
The structure is reasonable as a mitigation but has a load-bearing assumption the proposal doesn't test: that fallback-to-live stays rare. If new customers, volatile accounts, or edge segments hit the live path often, the system inherits the complexity of a new precompute pipeline *and* keeps the unfixed tail-latency problem — worse off than today in maintenance cost for no latency win on that slice.

**What I'm uncertain about**
- What fraction of report loads will actually be cache misses/stale (no data given, and it drives whether this solves the p99/timeout problem at all).
- What's actually causing p99 growth in the live path — if it's data-volume growth on one of the four services, the nightly batch will eventually hit the same wall.
- Whether the four upstream services support efficient bulk/batch reads at all, or whether the nightly job will just be 24x N sequential live-path calls with its own scaling problem.

### Contribution from data-engineer

### Data Engineer

> **Verdict:** revise
> **Top concern:** The denormalised store becomes a second, only-loosely-synchronised copy of customer data with no stated deletion/correction propagation path — that's a compliance gap, not a polish item.
> **Blocker before proceeding?** yes

**Source of truth**
The four upstream services remain authoritative for the underlying entities; the new store is derived, not a source of truth. The real risk isn't today's launch, it's six months out: once both a live join path and a batch join path exist, they will inevitably compute "the same" report from two independent code paths. If one is patched (bug fix, new field, changed business rule) and the other isn't, they silently diverge and nobody notices until a customer flags a report that doesn't match what they saw yesterday. This needs one shared join/transform implementation invoked by both paths, not two forks.

**Schema and contracts**
Undefined in the proposal: the key for a precomputed row (customer_id + report_id + as-of timestamp?), whether it's one row per report or versioned history, and what happens to the row when one of the four upstream services returns partial/errored data during the nightly run — is the report skipped, written with nulls, or held at last-known-good? Also undefined: what "stale" means as a field the read path can actually check, versus an implicit staleness the fallback logic infers. Both need to be explicit contracts before six weeks of work starts, not discovered during implementation.

**Consistency model**
This is eventual consistency with up to a 24h lag, but the live fallback means the *same* report can render fresh or 24h-stale on consecutive loads with no visible distinction to the customer — including cases where a customer just changed data that feeds their own report and reloads expecting to see it (a read-your-writes violation). If that's acceptable, it has to be a stated product decision with a UI signal ("as of HH:MM"), not an emergent property of a fallback branch.

**Pipelines and lineage**
Four services → nightly batch join → denorm store → read API, with a bypass straight from the four services on miss/stale. Whoever owns the batch job needs a defined behaviour for partial upstream failure (skip / partial-write / roll-forward-yesterday), and each precomputed row should carry a lineage marker (per-source snapshot timestamp) — without it, "this report is wrong" six weeks post-launch is undebuggable guesswork across five systems instead of one.

**Cost at scale**
Storage at 1x is cheap — one row per customer per report type, overwritten nightly. The real risk is batch *duration*, not storage: at 10x customers or report types, an unindexed nightly join can grow superlinearly and blow past the batch window, quietly turning "≤24h stale" into "≤48h stale or missing," which spikes live-path fallback load at the worst possible time (start of business day). Worth load-testing the batch job at 10x before committing to nightly cadence.

**Privacy and retention**
The denorm store duplicates whatever PII the reports contain. It now has its own retention and deletion lifecycle — if a customer is deleted or corrects their data mid-cycle, that change must propagate to this store too, and the 24h lag means deleted/corrected data could persist in a customer-facing report for up to a day after it's gone everywhere else. The proposal doesn't mention this at all.

**My position**
The core idea (precompute + fallback) is sound and the p99 problem is real, but the six-week estimate reads as happy-path-only. Staleness signalling, partial-batch-failure handling, and deletion propagation are exactly the "we'll figure it out later" items the anti-patterns here warn about, and at least one of them (deletion/PII propagation) is a compliance-adjacent blocker, not a nice-to-have.

**What I'm uncertain about**
Whether any of the four services already fire change events (which would make incremental refresh + deletion propagation far cheaper than a full nightly rebuild); actual report cardinality per customer (one report or many types, which changes storage and batch-window math); and whether the existing 22s p99 is dominated by one slow service or genuinely spread across all four, which changes whether precomputation is even the right lever versus fixing the slow join.

### Contribution from devops-sre

### DevOps / SRE

> **Verdict:** revise
> **Top concern:** The fallback path — the exact thing meant to make this safe — is untested under load and could turn a "some reports are stale" problem into a full outage on the same 8% of requests that already time out today.
> **Blocker before proceeding?** no

**Deployment story**
The nightly batch job and the new store are additive and can ship behind a flag, gated by percentage rollout on the read path — that's a reasonable story. The risk isn't the deploy, it's the coordination: the batch job needs to be running reliably *before* the read-side cutover, and someone needs to own the sequencing (backfill → validate → flip flag → monitor → ramp). Rollback is just flipping reads back to live-only, which is cheap — good.

**Observability**
Minimum dashboard: batch job success/duration/freshness-per-report, cache hit rate (precomputed vs. fallback-to-live), and fallback-path latency/error rate split out from precompute-path latency/error rate — today's p50/p99 conflates everything, tomorrow's must not. SLO should be framed as two numbers, not one: "% of reads served fresh (<24h)" and "p99 latency including fallback traffic." An error budget on batch job completion (e.g. job must finish and validate by 06:00 UTC, N consecutive failures pages) is the one alert that actually matters here.

**Failure modes**
- Batch job fails partway or times out overnight → some reports silently stale beyond 24h with no read-time signal, or fall back to live path en masse right at business-hours peak, spiking the very timeout rate this project exists to fix.
- Denormalized store falls behind schema/data changes in one of the four upstream services → reports look complete but are wrong, not missing — this doesn't trigger the fallback at all, it's a silent correctness failure, which is worse than a timeout.
- Fallback path is the same four-service fan-out that's already degrading; if precompute takes real load off it, fine, but if a bad batch run or a popular new report causes a fallback surge, that path has had zero recent load-testing and no one knows its behavior at 2-3x normal traffic.
- Store itself becomes a new dependency with its own outage mode — read errors from the store need to fail *open* to the live path, not fail the request; that fallback-on-store-error logic is untested and is exactly the kind of thing that's fine in the design doc and missing in the PR.

**Runbook adequacy**
Not written yet, and the brief doesn't mention one. On-call needs a clear decision tree: batch job failed — do we re-run it, and against what SLA before customers notice? Store is serving stale-beyond-threshold data — is there a kill switch to force live-only? Fallback surge is degrading the live path — can we shed load, and how? None of this exists today; it's new operational surface with no owner named.

**On-call burden**
Net effect is ambiguous, not clearly positive. It removes some pager load from live-path timeouts but adds a new nightly batch job that can fail silently, a new store that needs its own health checks, and a fallback path that's the union of both systems' failure modes. Without automated staleness alerting and a kill switch, this is more pages, not fewer, in the first few months.

**My position**
Not ship-and-pray, but not proceed-as-scoped either — the six-week estimate almost certainly doesn't include batch job monitoring, staleness alerting, fallback load testing, or a runbook, and skipping those is how this becomes a 3am problem within a month of launch.

**What I'm uncertain about**
Whether the four upstream services can absorb a full nightly backfill's read load without themselves degrading; what "stale" actually triggers a fallback (a fixed 24h TTL, or something smarter); and whether the fallback path has ever been load-tested at more than baseline traffic — if it hasn't, we don't actually know it's a safe fallback, we're assuming it.

### Contribution from product-manager

### Product Manager (Delivery)

> **Verdict:** revise
> **Top concern:** Six weeks is an engineering estimate for the happy path (nightly batch + read path), not for the actual hard part — a staleness detector and live fallback that behaves correctly under partial data and load; until that's decomposed, the date isn't real.
> **Blocker before proceeding?** yes — need the MVP cut and fallback acceptance criteria defined before committing to the six-week date.

**The MVP cut**
- In v1: nightly precompute + denormalised store for the highest-volume report type(s) only, read-path switch to serve from the store, and a fallback to live generation when the precomputed row is missing entirely (not stale — missing).
- Explicitly out / deferred: staleness-aware fallback (i.e., detecting a report is >24h old and deciding whether to serve it anyway or force a live regen) — deferred-but-not-forgotten, this is where most of the risk lives and it's being waved at in one sentence in the brief. Also out: covering all report types in v1 — pick the 1-2 that drive the p99/timeout numbers, not the long tail.

**Acceptance criteria**
- A customer viewing an in-scope report type sees a response in <2s p99 when a precomputed row exists, verified against a fixed set of report IDs before and after cutover.
- When a precomputed row is missing for an in-scope report, the request falls back to the live path and still resolves within the existing 30s gateway limit — not a new failure mode on top of the old one.
- An on-call engineer can look at one dashboard and tell, for any given report, whether it was served from cache or live, and how stale the cached version was, without grepping logs.
- The nightly batch job's own failure (partial run, one of the four upstream services down at 2am) has a defined behavior — degrade to live path for affected reports, not silently serve last-week's data or wedge the batch.

**Dependencies and sequencing**
Critical path: batch job design and the denormalised schema must land before the read-path switch can be tested end-to-end, so this is not parallelizable the way "six weeks" implies a team splitting into two workstreams — it's mostly sequential. Nothing here is called out as blocked on another team, but the brief is silent on who owns the nightly job's monitoring/alerting and whether the four upstream services can even support a coordinated nightly batch without their own load spike — that's an assumption riding along uninspected. Also sequencing-critical: staleness handling has to be designed before rollout, not bolted on after, because it changes what "done" means for the fallback.

**Prioritisation**
If the window halved to three weeks, I'd cut to one report type, no staleness UI/indicator, and manual (not automated) monitoring for the batch job — ship the precompute-and-fallback skeleton for the single worst-offending report, prove the pattern, defer everything else. I would not cut the "missing row falls back to live" behavior — that's the one thing standing between this shipping safely and a customer seeing a blank report.

**Rollout plan**
Ramp by report type and by customer segment, not big-bang: start with one report type at low traffic (or a beta cohort of customers who've opted into internal features), watch for a week, then expand. Rollback trigger is either a rise in error rate on the read path above current baseline, or the fallback-to-live rate exceeding an agreed threshold (suggesting the batch job isn't keeping up) — Data/Measurement should firm up that number. Week one, watch: cache-hit rate, fallback latency (is "falling back" actually still fast, or does it recreate the timeout problem for a subset of users), and batch job completion time/success rate.

**My position**
There's a proposal here, not yet a plan — the six-week estimate covers the part everyone already knows how to build (nightly batch, denormalised reads) and glosses over the part that determines whether this actually fixes the p99/timeout problem without creating a silent-staleness problem: what happens at the edges (missing row, stale row, batch failure). Until that's scoped with its own acceptance criteria, I'd treat six weeks as optimistic.

**What I'm uncertain about**
- Whether "up to 24 hours stale" means "serve it anyway, always" or "serve it if fresh enough, else regenerate live" — the brief doesn't say, and those are very different features with very different effort.
- Whether the four upstream services can absorb a nightly batch fan-out without themselves degrading (this is Architect/Feasibility's call, but it affects my sequencing).
- Whether "six weeks" was estimated against one report type or all of them — if the latter, the MVP cut above changes the number and I'd want it re-cut.

### Contribution from customer-voice

### Customer Voice

> **Verdict:** revise
> **Top concern:** Nobody has asked customers whether 24-hour-stale data is acceptable, and for at least one plausible user type (someone actively watching a metric they just acted on), stale-by-default is a worse failure mode than the current slow-but-eventually-fresh experience.
> **Blocker before proceeding?** no — but the "acceptable to most customers" assumption needs to be tested before or during build, not asserted after ship.

**Who specifically is this for?**
"Customers" isn't one user here. At minimum there are two: (1) the **routine checker** — opens the report on a schedule (daily/weekly standing meeting, EOM close) and mostly wants it to load without a spinner or a timeout page; and (2) the **just-acted user** — changed a setting, ran a campaign, fixed a data issue, then immediately opens the report to confirm the change took effect. Those two want opposite things from this proposal. The routine checker is well served by a nightly precompute. The just-acted user is actively harmed by it if they don't know they're looking at cached data — they'll draw a wrong conclusion ("my fix didn't work") from a report that just hasn't refreshed yet.

**What do they do today?**
Today they wait — up to 22s at p99, sometimes hitting the 30s timeout and having to retry or reload. That's bad, but it's *legible* bad: slow-or-broken is an obvious, expected failure users route around (retry, come back later, complain to support). What they don't currently experience is a report that loads fast and confidently shows them a wrong or outdated number. Some subset of power users/admins likely already have workarounds — checking a different admin panel, hitting an API directly, or just knowing "give it a minute" after making a change. That workaround knowledge won't transfer cleanly to a cached view.

**Will they actually do what this proposal requires?**
The proposal implicitly requires users to either (a) not care about freshness, or (b) notice and understand a staleness indicator if one is added. Neither is safely assumed. Users do not reliably read timestamps, badges, or "last updated" labels — that's exactly the kind of in-app-notice behaviour that gets ignored. If the fallback-to-live-path logic is invisible (i.e., users can't tell whether they're seeing cached or live data, or don't know *when* it'll be one vs. the other), you're trading a visible failure (timeout) for an invisible one (silently wrong data), which is generally the worse trade for trust even if it's better for the aggregate latency metric.

**Switching cost vs benefit**
There's no switching cost in the traditional sense — users aren't opting in, this is a backend change forced on them. So the question isn't "will they adopt it" but "will they notice the change in a way that erodes trust." For the routine checker, pure upside: faster, more reliable. For the just-acted user, the benefit (speed) doesn't offset the cost (confusion/mistrust) unless the UI clearly signals staleness and offers a way to force-refresh.

**My position**
This is a reasonable infra move for the majority use case, but it's being scoped as a backend/latency problem when it's also a UI-trust problem, and that half hasn't been designed or validated at all — the PM is guessing, not asking.

**What I'm guessing vs what I know**
I know (from general product experience, not this company's data): users routinely ignore passive freshness indicators, and the "I just changed something, why doesn't it show up" pattern is a very common support-ticket generator whenever caching is introduced silently. What I'm guessing: that a meaningful fraction of this specific customer base is the "just-acted" type — I have no usage data on this product's actual check-in patterns, and the PM hasn't asked customers either, so right now that split is unverified on both sides. That gap should be closed with even lightweight research (support ticket tagging, a few customer calls) before locking the six-week build, not treated as a known acceptable tradeoff.

## Your role

---
name: design-council-pragmatist
description: The Pragmatist role in a Design Council deliberation. Loaded by the Director as a counterweight when the council risks over-engineering, over-scoping, or solving imagined problems. Asks the simplest-thing-that-could-work question and pushes hard on whether load-bearing complexity is actually load-bearing.
---

# Pragmatist

You are the **Pragmatist** in a Design Council deliberation. Your job is to be the counterweight to the council's natural tendency to over-engineer, over-scope, and add complexity that isn't load-bearing.

Most rooms full of experts under-estimate the cost of complexity and over-estimate the cost of doing less. You are the correction.

## What to consult

Reach for `software-design-rules` when arguing for less.
`rules/a-philosophy-of-software-design.mini.md` on whether complexity is being added
faster than it is being hidden, and `rules/refactoring.mini.md` for Speculative Generality
— abstraction added for a need the spec does not have, which is what the 30% version is
usually up against.

## What you contribute

**The simplest version.** Strip the proposal back. What's the smallest thing that would deliver the core value? It often turns out the team is solving a problem they assume will exist at year-three scale while currently at year-zero scale. Surface this gap.

**Load-bearing vs ornamental.** Walk through the proposal's complexity and tag each piece: is it load-bearing for the actual problem, or is it ornament — a feature, an abstraction, a configuration option that someone wanted but isn't required? Ornaments compound.

**Real vs imagined problems.** Some problems the proposal solves are real and present. Others are anticipated, theoretical, or extrapolated from a single complaint. The two get treated identically in most planning. They shouldn't be.

**The do-nothing baseline.** What happens if we just don't do this? Most proposals never seriously consider this. Sometimes the do-nothing baseline is fine — the problem self-resolves, or the cost of the proposal exceeds the cost of the status quo. Force the question.

**The defer baseline.** Even if doing this is right, is *now* the right time? Doing it later means more information, possibly a different shape. What would have to be true for "later" to be wrong?

**Cost and stage realism.** Price the option, not just its complexity — name the rough **cost** (build + run + any SaaS/COGS it adds), and prefer **boring, proven** tech unless a shiny choice's payoff clears its added maintenance and learning cost. Judge the proposal against **stage**: the right call pre-product-market-fit (optimise for speed and learning) differs from the one at scale. And treat a deliberate shortcut as **debt with a due date** — incurring it for speed is fine *only* if the paydown is scheduled, not merely hoped for. *(Further reading — ideas, not copied text: Zach Goldberg, "The Startup CTO's Handbook," CC BY-NC-SA.)*

## What you do not do

You do not threat-model — that's Security Auditor.
You do not estimate effort — that's Feasibility (you might use their estimate).
You do not propose features the team didn't propose — you reduce.
You are not the Red Team. The Red Team finds why this fails; you find what's unnecessary even if it succeeds.

## Output format

```markdown
### Pragmatist

> **Verdict:** proceed · revise · reject  _(pick one)_
> **Top concern:** _one sentence — the one thing the Director must not miss from this lens._
> **Blocker before proceeding?** yes / no

**The simplest version of this**
<2–4 sentences. The smallest thing that would deliver the core value. Strip the proposal back.>

**Load-bearing vs ornamental**
- Load-bearing: <2–4 elements actually required for the core value>
- Ornamental: <2–4 elements that could be cut without losing core value>

**Real vs imagined problems**
<2–3 sentences. Which of the problems this addresses are present today, vs anticipated. Be honest.>

**The do-nothing baseline**
<2–3 sentences. What happens if we just don't do this. Be specific. Sometimes do-nothing is fine.>

**The defer baseline**
<1–3 sentences. If we did this in six months instead of now, what would be different — and would it be better or worse?>

**Cost & stage**
<1–2 lines. Rough cost of the option (build + run + added SaaS/COGS); is the right answer stage-dependent (PMF speed vs scale)? Is any shortcut debt with a scheduled paydown?>

**My position**
<1–2 sentences. Is the proposal appropriately scoped, or is it carrying weight it doesn't need to carry?>

**What I'm uncertain about**
<1–3 things. Things that would make the ornaments load-bearing — usually scale assumptions, customer commitments, or contractual obligations.>
```

## Anti-patterns

The first is reflexive minimalism. "Just do the simplest thing" is not analysis. Some proposals are appropriately scoped. If you can't find ornament, say so honestly — that's a useful finding.

The second is treating "ship less" as always right. Sometimes the bigger version is the right call because it earns the right to exist. Your job is to *force the conversation*, not always to win it.

The third is overlapping with the Red Team. You ask "what's unnecessary even if this succeeds". They ask "why this fails". Different questions. Stay on yours.


---

Write your contribution now.
